﻿明年就是找工作了，又要开始刷题了，把之前做过的题目再梳理整理一遍，但愿明年不要那么拉跨，祈祷明年能找到工作，千万不能毕业就失业。



分类别解析leetcode上的一些相关的例题路，代码采用**C++**实现。

使用**python**刷题分类整理的笔记,请参考这个仓库的v1 tag:  [https://github.com/lxztju/leetcode-algorithm/tree/v1](https://github.com/lxztju/leetcode-algorithm/tree/v1)



## 算法题目分类

按照不同的类别整理leetcode题目，每个类别大概整理10-20道题目，每个类别的题目均附上可通过的c++与python代码，并针对每个类别的典型题目，附上清晰的题目思路算法逻辑解析。



基本上分类的内容差不多总结到这里，随后再学习中补充别的类型的算法。







## 更多笔记资料

* 微信公众号： 小哲AI

  ![wechat_QRcode](images/wechat_QRcode.jpg)

* GitHub地址： [https://github.com/lxztju/leetcode-algorithm](https://github.com/lxztju/leetcode-algorithm)

* csdn博客： [https://blog.csdn.net/lxztju](https://blog.csdn.net/lxztju)
* 知乎专栏： [小哲AI](https://www.zhihu.com/column/c_1101089619118026752)
* AI研习社专栏：[小哲AI](https://www.yanxishe.com/column/109)

